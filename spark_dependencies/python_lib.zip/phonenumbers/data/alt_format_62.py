"""Auto-generated file, do not edit by hand. 62 metadata"""
from ..phonemetadata import NumberFormat

PHONE_ALT_FORMAT_62 = [NumberFormat(pattern='(\\d{2})(\\d{3,4})(\\d{4})', format='\\1 \\2', leading_digits_pattern=['2[124]|[36]1'])]
